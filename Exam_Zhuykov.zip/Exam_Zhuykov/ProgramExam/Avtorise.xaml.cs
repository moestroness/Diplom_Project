﻿using ProgramExam.DataBaseConnect;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProgramExam
{

    public partial class Avtorise : Page
    {
            
        private Users _currentUser;
        public Avtorise()
        {
            InitializeComponent();
            DataContext = _currentUser;
        }

        public void avtorizat()
        {
            try 
            { 
            var user = ZiznFarmEntities.GetContext().Users.FirstOrDefault(x=>x.login==logine.Text && x.Password == Passe.Text);
                if (user == null)
                {
                    MessageBox.Show("Пользователь не найден");
                }
                else
                {
                    if (user.Role == "Сотрудник")
                    {
                        Manager.MFrame.Navigate(new AddzakazPage());
                    }
                    else if (user.Role == "Клиент")
                        Manager.MFrame.Navigate(new AddzakazPage());

                }
                
            }
            catch(Exception ex)
            {
                MessageBox.Show("Ошибка!"+ex.Message.ToString());
            }
            
        }

        private void AvtoriseButton_Click(object sender, RoutedEventArgs e)
        {
            avtorizat();
        }
        //ssd
    }
    
}
